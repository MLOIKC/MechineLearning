import os
import sys
from turtle import done
sys.path.append(os.path.abspath(
    os.path.join(
        os.path.abspath(__file__), '..', '..'
    )
))

from typing import Any, Tuple
import math
from numpy import *
import matplotlib.pyplot as plt
import operator
import time

from dlframe import DataSet, Splitter, Model, Judger, WebManager
from build.lib.dlframe.TestDataset import TestDataset
from build.lib.dlframe.TestSplitter import TestSplitter
from build.lib.dlframe.TestModel import TestModel
from build.lib.dlframe.TestJudger import TestJudger

def loadDataSet(fileName):
	dataMat = []
	labelMat = []
	with open(fileName) as fr:
		for line in fr.readlines():
			lineArr = line.strip().split('\t')
			dataMat.append([float(lineArr[0]), float(lineArr[1])])
			labelMat.append(float(lineArr[2]))
	return dataMat, labelMat

if __name__ == '__main__':
    trainDataSet, trainLabel = loadDataSet('D:\作业\机器学习实践\支持向量机\crane controller data.txt')
    WebManager().register_dataset(
        TestDataset(trainDataSet), 'crane controller data'
    ).register_dataset(
        TestDataset(30), '20_nums'
    ).register_splitter(
        TestSplitter(0.8), 'ratio:0.8'
    ).register_splitter(
        TestSplitter(0.5), 'ratio:0.5'
    ).register_model(
        TestModel(1e-3)
    ).register_judger(
        TestJudger()
    ).start()